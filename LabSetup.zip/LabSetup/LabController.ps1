# ===========================================================================
# ULTIMATE ENFORCER v7.0: Dr. V.S. Krishna Govt. Degree College (Autonomous)
# Features: Dynamic Desktop Logout Shortcut + Instant Lock
# ===========================================================================

# -------------------- 1. CONFIGURATION --------------------
$SystemID    = "CS-22"   
$PWA_URL     = "https://thrinadh360.github.io/drvsklab/index.html"
$LOGOUT_URL  = "https://thrinadh360.github.io/drvsklab/instant-logout.html"
$BACKEND_URL = "https://script.google.com/macros/s/AKfycbworz63t_h5Y90GfiH3kQVQX3H77om2PT7c8UDIKVufWj5YwNK71Ik5q0C7588Db64s/exec"

# -------------------- 2. HARDWARE HANDSHAKE --------------------
while (!(Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet)) { Start-Sleep -Seconds 2 }
$MAC = (Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object -First 1).MacAddress.Replace("-","").Replace(":","")
$FullLogoutURL = "$($LOGOUT_URL)?sysId=$($SystemID)&mac=$($MAC)"
$FullSigninURL = "$($PWA_URL)?sysId=$($SystemID)&mac=$($MAC)"

$Sync = [hashtable]::Synchronized(@{ TriggerLogout = $false; IsDesktopActive = $false; LastActionID = "" })

# -------------------- 3. CORE FUNCTIONS --------------------

function Manage-Shortcut {
    param([string]$Action)
    $DesktopPath = [System.IO.Path]::Combine([Environment]::GetFolderPath("Desktop"), "LOGOUT-LAB.url")
    if ($Action -eq "Create") {
        $Shortcut = "[InternetShortcut]`r`nURL=$FullLogoutURL`r`nIDList=`r`nIconIndex=27`r`nIconFile=shell32.dll"
        $Shortcut | Out-File $DesktopPath -Encoding ASCII
    } elseif ($Action -eq "Delete") {
        Remove-Item $DesktopPath -ErrorAction SilentlyContinue
    }
}

function Terminate-All-Apps {
    Write-Host "Cleaning system..." -ForegroundColor Red
    $Apps = @("msedge", "chrome", "winword", "excel", "powerpnt", "code", "notepad")
    foreach ($app in $Apps) { Get-Process $app -ErrorAction SilentlyContinue | Stop-Process -Force }
}

function Start-Kiosk {
    Manage-Shortcut -Action "Delete"
    Terminate-All-Apps
    Get-Process explorer -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Process "msedge.exe" -ArgumentList "--kiosk `"$FullSigninURL`" --edge-kiosk-type=fullscreen --no-first-run"
    $Sync.IsDesktopActive = $false
}

function Unlock-Desktop {
    Write-Host "Session Active." -ForegroundColor Green
    Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Process "explorer.exe"
    Manage-Shortcut -Action "Create"
    $Sync.IsDesktopActive = $true
}

function Send-Cloud-Logout {
    param($Reason)
    $Payload = @{ year="---"; sem="---"; name="SYSTEM-LOCK"; roll=$Reason; sysId=$SystemID; mac=$MAC; time=(Get-Date -Format "hh:mm:ss tt"); type="Logout" } | ConvertTo-Json
    try { Invoke-RestMethod -Uri $BACKEND_URL -Method Post -Body $Payload -ContentType "application/json" } catch { }
}

# -------------------- 4. MONITORING LOOP --------------------
$Global:EventSync = $Sync
Register-ObjectEvent -InputObject (New-Object Microsoft.Win32.SystemEvents) -EventName "SessionSwitch" -Action {
    if ($EventArgs.Reason -match "SessionLock|Logoff") { $EventSync.TriggerLogout = $true }
} | Out-Null

Start-Kiosk

while($true) {
    if ($Sync.TriggerLogout) {
        Send-Cloud-Logout -Reason "WIN-LOCK"
        $Sync.TriggerLogout = $false
        Start-Kiosk
    }

    try {
        $data = Invoke-RestMethod -Uri $BACKEND_URL -Method Get -TimeoutSec 5
        $myLog = $data | Where-Object { $_.SystemID -eq $SystemID } | Select-Object -Last 1

        if ($myLog) {
            $CurrentActionID = $myLog.Timestamp + $myLog.Type

            # LOGIC: DETECT LOGIN
            if ($myLog.Type -match "CS|AI|Minor|Lecturer|Guest") {
                if ($Sync.IsDesktopActive -eq $false) {
                    Unlock-Desktop
                    $Sync.LastActionID = $CurrentActionID
                }
            }
            
            # LOGIC: DETECT LOGOUT
            if ($myLog.Type -eq "Logout" -and $CurrentActionID -ne $Sync.LastActionID) {
                $Sync.LastActionID = $CurrentActionID
                Start-Kiosk
                rundll32.exe user32.dll,LockWorkStation
            }
        }
    } catch { }

    if ($Sync.IsDesktopActive -eq $false -and !(Get-Process msedge -ErrorAction SilentlyContinue)) { Start-Kiosk }
    $SleepTime = if ($Sync.IsDesktopActive) { 5 } else { 1 }
    Start-Sleep -Seconds $SleepTime
}