# -------------------- 1. CONFIGURATION --------------------
$SystemID    = "CS-22"   
$PWA_URL     = "https://drvskcslab.netlify.app/"
$BACKEND_URL = "https://script.google.com/macros/s/AKfycbworz63t_h5Y90GfiH3kQVQX3H77om2PT7c8UDIKVufWj5YwNK71Ik5q0C7588Db64s/exec"

# -------------------- 2. ROBUST INTERNET & MAC CHECK --------------------
Write-Host "Waiting for WiFi..." -ForegroundColor Cyan
while (!(Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet)) { Start-Sleep -Seconds 2 }

# Get MAC address specifically from the active WiFi adapter
$MAC = (Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object -First 1).MacAddress

# Remove any spaces or dashes from MAC to keep URL clean
$MAC = $MAC.Replace("-","").Replace(":","")

# Construct the exact URL the PWA expects
$FullURL = "$($PWA_URL)?sysId=$($SystemID)&mac=$($MAC)"

Write-Host "Launching $SystemID with MAC $MAC" -ForegroundColor Green

# -------------------- 3. LAUNCH --------------------
# Use -NoFirstRun to prevent Edge setup popups
Start-Process "msedge.exe" -ArgumentList "--kiosk `"$FullURL`" --edge-kiosk-type=fullscreen --no-first-run"