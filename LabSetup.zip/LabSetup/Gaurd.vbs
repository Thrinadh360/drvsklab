Set objShell = CreateObject("WScript.Shell")
Do
    ' Check if PowerShell is running our script
    strCommand = "powershell.exe -ExecutionPolicy Bypass -File C:\LabSetup\LabController.ps1"
    ' 0 means hidden window
    objShell.Run strCommand, 0, True 
    ' If the script exits (or is killed), the loop restarts it immediately
Loop