# ===========================================================================
# ULTIMATE ENFORCER v5.0: Dr. V.S. Krishna Govt. Degree College (Autonomous)
# Features: Instant Kiosk Exit, Auto-Logout on Lock/Sleep/Shutdown, WiFi Guard
# ===========================================================================

# -------------------- 1. CONFIGURATION --------------------
$SystemID    = "CS-22"   
$PWA_URL     = "https://thrinadh360.github.io/drvsklab/"
$BACKEND_URL = "https://script.google.com/macros/s/AKfycbworz63t_h5Y90GfiH3kQVQX3H77om2PT7c8UDIKVufWj5YwNK71Ik5q0C7588Db64s/exec"

# -------------------- 2. STARTUP & WIFI GUARD --------------------
Write-Host "Initializing System Watchdog for $SystemID..." -ForegroundColor Cyan
while (!(Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet)) { Start-Sleep -Seconds 2 }

# Get MAC Address (Optimized)
$MAC = (Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object -First 1).MacAddress
if ($null -eq $MAC) { $MAC = "000000000000" } else { $MAC = $MAC.Replace("-","").Replace(":","") }

$FullURL = "$($PWA_URL)?sysId=$($SystemID)&mac=$($MAC)"

# Create a Sync Object to share data between background events and main loop
$Sync = [hashtable]::Synchronized(@{ TriggerLogout = $false; IsDesktopActive = $false; LastActionID = "" })

# -------------------- 3. CORE FUNCTIONS --------------------

function Send-Cloud-Logout {
    param($Reason)
    Write-Host "Event Detected ($Reason): Sending Logout..." -ForegroundColor Yellow
    $Payload = @{
        year = "---"; sem = "---"; name = "AUTO-LOGOUT"; roll = $Reason;
        sysId = $SystemID; mac = $MAC; time = (Get-Date -Format "hh:mm:ss tt"); type = "Logout"
    } | ConvertTo-Json
    try { Invoke-RestMethod -Uri $BACKEND_URL -Method Post -Body $Payload -ContentType "application/json" } catch { }
}

function Start-Kiosk {
    Write-Host "Securing System: Starting Kiosk..." -ForegroundColor Cyan
    Get-Process explorer -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 1
    Start-Process "msedge.exe" -ArgumentList "--kiosk `"$FullURL`" --edge-kiosk-type=fullscreen --no-first-run --disable-features=EdgeTranslate"
    $Sync.IsDesktopActive = $false
}

function Unlock-Desktop {
    Write-Host "Sign-In Verified: Unlocking Windows..." -ForegroundColor Green
    Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Process "explorer.exe"
    # Open Logout window in background
    Start-Process "msedge.exe" -ArgumentList "--window-size=450,650 `"$FullURL&page=checkout`"" 
    $Sync.IsDesktopActive = $true
}

# -------------------- 4. KERNEL EVENT LISTENERS --------------------

# A. Watch for Lock/Logoff
Register-ObjectEvent -InputObject (New-Object Microsoft.Win32.SystemEvents) -EventName "SessionSwitch" -Action {
    if ($EventArgs.Reason -match "SessionLock|Logoff") { $EventSync.TriggerLogout = $true }
} -MessageData $Sync | Out-Null

# B. Watch for Shutdown/Power End
Register-ObjectEvent -InputObject (New-Object Microsoft.Win32.SystemEvents) -EventName "SessionEnding" -Action {
    $EventSync.TriggerLogout = $true
} -MessageData $Sync | Out-Null

# C. Watch for Sleep
Register-ObjectEvent -InputObject (New-Object Microsoft.Win32.SystemEvents) -EventName "PowerModeChanged" -Action {
    if ($EventArgs.Mode -eq 'Suspend') { $EventSync.TriggerLogout = $true }
} -MessageData $Sync | Out-Null

# Define $EventSync for the actions above
$Global:EventSync = $Sync

# -------------------- 5. MONITORING LOOP --------------------
Start-Kiosk

while($true) {
    # Check if a background event triggered a logout
    if ($Sync.TriggerLogout) {
        Send-Cloud-Logout -Reason "SYS-EVENT"
        $Sync.TriggerLogout = $false
        Start-Kiosk
    }

    try {
        # Fetch latest data from Google Sheet
        $data = Invoke-RestMethod -Uri $BACKEND_URL -Method Get -TimeoutSec 5
        $myLog = $data | Where-Object { $_.SystemID -eq $SystemID } | Select-Object -Last 1

        if ($myLog) {
            $CurrentActionID = $myLog.Timestamp + $myLog.Type

            # LOGIC: If a user is signed in (CS, AI, Minor, etc.)
            if ($myLog.Type -match "CS|AI|Minor|Lecturer|Guest") {
                if ($Sync.IsDesktopActive -eq $false) {
                    Unlock-Desktop
                    $Sync.LastActionID = $CurrentActionID
                }
            }
            
            # LOGIC: If a user signs out OR 5 PM Auto-Logout hits
            if ($myLog.Type -eq "Logout" -and $CurrentActionID -ne $Sync.LastActionID) {
                $Sync.LastActionID = $CurrentActionID
                Write-Host "Logout Command Received." -ForegroundColor Red
                Start-Kiosk
                rundll32.exe user32.dll,LockWorkStation
            }
        }
    } catch { 
        Write-Host "WiFi/Sync Pulse failed. Retrying..." -ForegroundColor Gray
    }

    # Watchdog: Relaunch Browser if it's closed while desktop is still locked
    if ($Sync.IsDesktopActive -eq $false) {
        if (!(Get-Process msedge -ErrorAction SilentlyContinue)) { Start-Kiosk }
        Start-Sleep -Seconds 1 # High speed polling at login screen
    } else {
        Start-Sleep -Seconds 5 # Low power polling after login
    }
}